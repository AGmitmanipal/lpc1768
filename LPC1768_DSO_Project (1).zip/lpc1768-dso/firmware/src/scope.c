#include "scope.h"

void scope_arm(Scope *s, ScopeConfig cfg) {
    if (cfg.threshold < cfg.hysteresis) cfg.threshold = cfg.hysteresis;
    if (cfg.threshold > 4095u - cfg.hysteresis)
        cfg.threshold = (uint16_t)(4095u - cfg.hysteresis);
    s->cfg = cfg;
    s->write = s->filled = s->remaining = 0;
    s->waited = 0;
    s->armed_edge = s->triggered = s->ready = s->forced = false;
}

bool scope_feed(Scope *s, uint16_t code) {
    if (s->ready) return true;
    code &= 4095u;
    s->ring[s->write] = code;
    if (++s->write == SCOPE_N) s->write = 0;
    if (s->filled < SCOPE_N) ++s->filled;
    if (s->triggered) {
        if (--s->remaining == 0) s->ready = true;
        return s->ready;
    }
    if (s->waited != UINT32_MAX) ++s->waited;
    bool crossing = s->armed_edge &&
        (s->cfg.falling ? code <= s->cfg.threshold : code >= s->cfg.threshold);
    if (s->cfg.falling ? code >= s->cfg.threshold + s->cfg.hysteresis :
                        code <= s->cfg.threshold - s->cfg.hysteresis)
        s->armed_edge = true;
    /* Ignore early crossings: all displayed pre-trigger samples must be valid. */
    if (crossing && s->filled <= SCOPE_PRE) s->armed_edge = false;
    if (s->filled > SCOPE_PRE) {
        bool timeout = s->cfg.mode == MODE_AUTO && s->waited >= s->cfg.sample_hz / 4u;
        if (crossing || timeout) {
            s->triggered = true;
            s->forced = !crossing;
            s->remaining = SCOPE_N - SCOPE_PRE - 1u;
        }
    }
    return false;
}

void scope_copy(const Scope *s, uint16_t output[SCOPE_N]) {
    /* When complete, the next write index is the oldest retained sample. */
    uint16_t j = s->write;
    for (uint16_t i = 0; i < SCOPE_N; ++i) {
        output[i] = s->ring[j];
        if (++j == SCOPE_N) j = 0;
    }
}

Measurements scope_measure(const uint16_t *data, uint16_t n,
                           uint32_t sample_hz, uint32_t reference_uv) {
    Measurements m = {4095, 0, 0, 0, 0, false};
    if (!n) { m.minimum = 0; return m; }
    uint32_t sum = 0;
    for (uint16_t i = 0; i < n; ++i) {
        if (data[i] < m.minimum) m.minimum = data[i];
        if (data[i] > m.maximum) m.maximum = data[i];
        sum += data[i];
    }
    m.mean_uv = (uint32_t)(((uint64_t)sum * reference_uv) / ((uint32_t)n * 4095u));
    m.vpp_uv = (uint32_t)(((uint64_t)(m.maximum - m.minimum) * reference_uv) / 4095u);
    m.clipped = m.minimum <= 2 || m.maximum >= 4093;
    if (m.maximum - m.minimum < 32) return m;
    uint16_t mid = (uint16_t)((m.minimum + m.maximum) / 2u);
    uint16_t hyst = (uint16_t)((m.maximum - m.minimum) / 16u);
    if (hyst < 4) hyst = 4;
    bool armed = false;
    uint32_t first = 0, last = 0, count = 0;
    for (uint16_t i = 1; i < n; ++i) {
        if (data[i-1] <= mid - hyst) armed = true;
        if (armed && data[i-1] < mid && data[i] >= mid) {
            uint32_t t = ((uint32_t)(i - 1u) << 16) +
                (((uint32_t)(mid - data[i-1]) << 16) / (data[i] - data[i-1]));
            if (!count) first = t;
            last = t; ++count; armed = false;
        }
    }
    if (count >= 2 && last > first)
        m.frequency_mhz = (uint32_t)(((uint64_t)sample_hz * 1000u * 65536u *
                                      (count - 1u)) / (last - first));
    return m;
}

uint16_t scope_y(uint16_t code, uint16_t height) {
    if (!height) return 0;
    return (uint16_t)(((uint32_t)(4095u - (code & 4095u)) * (height - 1u)) / 4095u);
}
