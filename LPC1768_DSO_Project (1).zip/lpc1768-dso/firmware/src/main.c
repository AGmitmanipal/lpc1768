#include "config.h"
#include "hw.h"
#include "scope.h"
#include "acquisition.h"
#include "display.h"
static uint16_t frame[SCOPE_N];
static const uint32_t rates[]={1000,5000,10000,20000};
static const uint16_t windows[]={100,200,500,1000};
int main(void) {
    clock_init();board_init();display_init();aux_init();acquisition_init();
    ScopeConfig cfg={5000,2048,16,MODE_AUTO,false};
    uint8_t rate=1,zoom=1;
    bool running=true,have_frame=false,forced=false,fault_latched=false;
    display_status(cfg,"WAIT",windows[zoom]);
    aux_update(cfg.sample_hz,"WAIT");acquisition_start(cfg);
    for(;;) {
        if(acquisition_failed() && !fault_latched) {
            running=false;fault_latched=true;acquisition_stop();
            display_status(cfg,"ADC ERROR",windows[zoom]);aux_update(cfg.sample_hz,"ADC ERROR");
        }
        if(acquisition_ready()) {
            forced=acquisition_copy(frame);have_frame=true;acquisition_stop();
            if(cfg.mode==MODE_SINGLE)running=false;
            const char *status=running?(forced?"AUTO":"TRIG"):"HOLD";
            display_frame(frame,cfg,status,windows[zoom]);aux_update(cfg.sample_hz,status);
            if(running)acquisition_start(cfg);
        }
        uint8_t key=keys_poll();
        if(!key) continue;
        acquisition_stop();
        if(key&1u) { running=!running;fault_latched=false; }
        bool invalidate=false;
        if(key&2u) {rate=(uint8_t)((rate+1u)%4u);cfg.sample_hz=rates[rate];invalidate=true;}
        if(key&4u) cfg.mode=(ScopeMode)((cfg.mode+1u)%3u);
        if(key&8u) cfg.falling=!cfg.falling;
        if(key&16u) { if(cfg.threshold<3951u) cfg.threshold+=128u; }
        if(key&32u) { if(cfg.threshold>144u) cfg.threshold-=128u; }
        if(key&64u) zoom=(uint8_t)((zoom+1u)%4u);
        /* A previous frame must never be relabelled with a different sample rate. */
        if(invalidate) {have_frame=false;display_init();}
        const char *status=running?"WAIT":"HOLD";
        if(have_frame) display_frame(frame,cfg,status,windows[zoom]);
        else display_status(cfg,status,windows[zoom]);
        aux_update(cfg.sample_hz,status);
        if(running)acquisition_start(cfg);
    }
}
