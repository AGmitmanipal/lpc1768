#ifndef DISPLAY_H
#define DISPLAY_H
#include "scope.h"
void display_init(void);
void display_status(ScopeConfig cfg, const char *status, uint16_t window);
void display_frame(const uint16_t data[SCOPE_N], ScopeConfig cfg,
                   const char *status, uint16_t window);
#endif
